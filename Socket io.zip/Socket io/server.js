// No need to change the pre-written code
// Implement the features in io.on() section
import cors from "cors";
import express from "express";
import http from "http";
import { Server } from "socket.io";

export const app = express();
app.use(cors());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  console.log("Connection made.");

  // Write your code here

  // Handle 'join' event when a user joins a room
  socket.on("join", (data) => {
    const { username, room } = data;
    socket.emit("message", { text: `${data.username}` });
    socket.broadcast.to(room).emit("message", {
      text: `${username} has joined`,
    });
    socket.join(room);
  });

  // Handle 'sendMessage' event when a user sends a message
  socket.on("sendMessage", (data) => {
    io.to(data.room).emit("message", {
      username: data.username,
      text: data.message,
    });
  });

  socket.on("disconnect", () => {
    console.log("Connection disconnected.");
  });
});

export { server };
